#!/bin/sh
java -jar ./tool/ArduImageCapture.jar

